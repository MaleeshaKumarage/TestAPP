export const API_URL = "https://covid19assistantbot.azurewebsites.net";
//export const API_URL = "http://localhost:3978";